# Setup environment variables for performance on Xeon
export LD_PRELOAD=${CONDA_PREFIX}/lib/libstdc++.so.6
export KMP_BLOCKTIME=INF
export KMP_TPAUSE=0
export KMP_SETTINGS=1
export KMP_AFFINITY=granularity=fine,compact,1,0
export KMP_FORJOIN_BARRIER_PATTERN=dist,dist
export KMP_PLAIN_BARRIER_PATTERN=dist,dist
export KMP_REDUCTION_BARRIER_PATTERN=dist,dist
export LD_PRELOAD=${LD_PRELOAD}:${CONDA_PREFIX}/lib/libiomp5.so # Intel OpenMP
# Tcmalloc is a recommended malloc implementation that emphasizes fragmentation avoidance and scalable concurrency support.
export LD_PRELOAD=${LD_PRELOAD}:${CONDA_PREFIX}/lib/libtcmalloc.so
#export OMP_NUM_THREADS=64
export OMP_NUM_THREADS=32

#  --quantize
#numactl --localalloc --physcpubind=0-31 python run_codegen_INT8.py --ipex --token_latency --jit --dtype int8 --quantize --int8_bf16_mixed --input_tokens 512 --max_new_tokens 432 --num_warmup 5 --num_iter 10 --greedy --benchmark 
#numactl --localalloc --physcpubind=0-31,64-95 python run_codegen_INT8.py --ipex --token_latency --jit --dtype int8  --int8_bf16_mixed --input_tokens 512  --max_new_tokens 432 --num_warmup 5 --num_iter 10 --greedy --benchmark 
#numactl --localalloc --physcpubind=0-31 python run_codegen_INT8.py --ipex --token_latency --jit --dtype int8  --int8_bf16_mixed --input_tokens 512  --max_new_tokens 432 --num_warmup 5 --num_iter 10 --greedy --benchmark 

numactl --localalloc --physcpubind=0-31 python run_codegen_INT8.py --ipex --token_latency --jit --dtype bfloat16  --input_tokens 512  --max_new_tokens 432 --num_warmup 5 --num_iter 10 --greedy --benchmark 
#numactl --localalloc --physcpubind=0-31 python run_codegen_INT8.py --ipex --token_latency --jit --dtype bfloat16 --input_tokens 2048 --max_new_tokens 64 --num_warmup 10 --num_iter 100 --greedy --benchmark &> logs_bfloat16.log

#numactl --localalloc --physcpubind=0-31 python run_codegen_INT8.py --ipex --token_latency --jit --dtype float32 --input_tokens 2048 --max_new_tokens 64 --num_warmup 10 --num_iter 100 --greedy --benchmark &> logs_float32.log
