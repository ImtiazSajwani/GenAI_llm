import argparse
import re
import time
import json
import os
import pathlib
import torch
import types
from pathlib import Path
from datasets import load_dataset
from torch.nn.functional import pad
from torch.utils.data import DataLoader
import transformers
import huggingface_hub

import numpy as np
from itertools import chain
from transformers import AutoModelForCausalLM, AutoTokenizer, AutoConfig, LlamaForCausalLM

# we'll use this for jit tracing and calibrating
prompt_texts = ["Translate to German: My name is Arthur",
                "Please answer to the following question. Who is going to be the next Ballon d'or?",
                "Q: Can Geoffrey Hinton have a conversation with George Washington? Give the rationale before answering.",
                "Please answer the following question. What is the boiling point of Nitrogen?",
                "Answer the following yes/no question. Can you write a whole Haiku in a single tweet?",
                "Answer the following yes/no question by reasoning step-by-step. Can you write a whole Haiku in a single tweet?",
                "Q: ( False or not False or False ) is? A: Let's think step by step",
                "The square root of x is the cube root of y. What is y to the power of 2, if x = 4?",
                "Premise: At my age you will probably have learnt one lesson. Hypothesis: It's not certain how many lessons you'll learn by your thirties. Does the premise entail the hypothesis?",
]

def set_seed(args):
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)


def benchmark_runtime(model,
                      tokenizer,
                      args,
                      generate_kwargs):
    total_time = 0
    num_iter = args.num_iter

    prefix_size = int(args.input_tokens) - int(args.max_new_tokens)
    #input seq = 8
    #input_ids = torch.randint(1, 10000, (8, prefix_size)).to(torch.long)
    input_ids = torch.randint(1, 10000, (1, prefix_size)).to(torch.long)

    # dtype
    amp_enabled = False
    if args.dtype == "bfloat16" or args.int8_bf16_mixed:
        amp_enabled = True
        amp_dtype = torch.bfloat16
    else:
        amp_enabled = False
        amp_dtype = torch.float32

    total_list = []
    with torch.inference_mode(), torch.no_grad(), torch.autocast(device_type="cpu", enabled=amp_enabled, dtype=amp_dtype if amp_enabled else None,):
        for i in range(num_iter):
            ts = time.time()
            # input_ids = tokenizer(prompt, return_tensors="pt").input_ids
            output = model.generate(input_ids, **generate_kwargs)
            # print(output)

            gen_ids =  output[0] if args.token_latency else output
            gen_text = tokenizer.batch_decode(gen_ids, skip_special_tokens=True)
            te = time.time()
            
            input_tokens_lengths = [x.shape[0] for x in input_ids]
            output_tokens_lengths = [x.shape[0] for x in gen_ids]
            total_new_tokens = [o for i, o in zip(input_tokens_lengths, output_tokens_lengths)]

            # print(gen_text, total_new_tokens, flush=True)
            # print("Iteration: %d, Time: %.6f sec" % (i, te - ts), flush=True)

            if i >= args.num_warmup:
                total_time += te - ts
                if args.token_latency:
                    total_list.append(output[1])

    print("\n", "+"*10, "Summary", "+"*10)
    latency = total_time/(args.num_iter - args.num_warmup)
    print("Inference latency: %.3f." % latency)
    # print(total_list)

    if args.token_latency:
        import numpy as np
        from itertools import chain
        first_latency = np.mean([x[0] for x in total_list])
        average_2n = list(chain(*[x[1:] for x in total_list]))
        average_2n.sort()
        average_2n_latency = np.mean(average_2n)
        p90_latency = average_2n[int(len(average_2n)*0.9)]
        p99_latency = average_2n[int(len(average_2n)*0.99)]

        print("Average first token latency: %.3f sec. " % first_latency)
        print("Average second token latency: %.3f sec. " % average_2n_latency)
        print("P90 second token latency: %.3f sec. " % p90_latency)
        print("P99 second token latency: %.3f sec. " % p99_latency)


def measure_accuracy(
    model,
    tokenizer,
    dataloader,
    args,
    ):
    # # from lm_eval.arguments import EvalArguments
    # from lm_eval.evaluator import Evaluator
    # from lm_eval.tasks import ALL_TASKS
    dataset = load_dataset("openai_humaneval", split="test")

    for data in dataset:
        input_ids = tokenizer("def factorial(x): \n # this python function returns the factorial of a number \n", return_tensors="pt")["input_ids"]
        # input_ids = tokenizer("Write a python function to compute factorial of a number \n" , return_tensors="pt")["input_ids"]
        output = model.generate(input_ids, max_new_tokens=128)
        gen_ids =  output[0]
        gen_text = tokenizer.batch_decode(gen_ids, skip_special_tokens=True)
        print(gen_text)
        break

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model_type",
        default="llama",
        type=str,
        help="Model type selected in the list: ",
    )
    parser.add_argument(
        "--model_name_or_path",
        #default="Salesforce/codegen-2B-multi",
        default="meta-llama/Llama-2-7b-hf",
        type=str,
        help="Path to pre-trained model or shortcut name selected in the list: ",
    )

    parser.add_argument(
        "--dtype",
        default="int8",
        type=str,
        choices=["float32", "bfloat16", "int8"],
        help="Select the data type for computation: supports bfloat16, and float32"
    )

    parser.add_argument("--input_tokens", default="32", type=str, help="input tokens length if needed")
    parser.add_argument("--max_new_tokens", default=32, type=int, help="output max new tokens ")

    parser.add_argument("--prompt", type=str, default=None, help="input prompt")
    parser.add_argument("--greedy", action="store_true")
    parser.add_argument("--ipex", action="store_true")
    parser.add_argument("--jit", action="store_true")
    parser.add_argument("--num_iter", default=100, type=int, help="number of iterations")
    parser.add_argument("--num_warmup", default=10, type=int, help="number of warmup steps")
    parser.add_argument("--batch_size", default=1, type=int, help="batch size")
    parser.add_argument("--token_latency", action="store_true", help="get token latency")

    parser.add_argument("--quantize", action="store_true")
    parser.add_argument("--int8_bf16_mixed", action="store_true")
    parser.add_argument("--output_dir", default="./output_dir/")
    parser.add_argument("--accuracy", action="store_true")
    parser.add_argument("--task", default="humaneval", type=str, help="tasks list for accuracy validation")
    parser.add_argument("--benchmark", action="store_true")


    parser.add_argument("--seed", type=int, default=42, help="random seed for initialization")

    args = parser.parse_args()

    # set seed 
    set_seed(args)
    huggingface_hub.login(token="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")

    if args.ipex:
        import intel_extension_for_pytorch as ipex
        try:
            ipex._C.disable_jit_linear_repack()
        except Exception:
            pass
    
    if args.jit:
        torch._C._jit_set_texpr_fuser_enabled(False)

    # dtype
    amp_enabled = False
    if args.dtype == "bfloat16" or args.int8_bf16_mixed:
        amp_enabled = True
        amp_dtype = torch.bfloat16
    else:
        amp_enabled = False
        amp_dtype = torch.float32

    dtype = getattr(torch, args.dtype)

    # Load the model and tokenizers 
    config = AutoConfig.from_pretrained(args.model_name_or_path, torchscript=args.jit)

    # if args.kv_cache_dtype != "None":
    #     args.kv_cache_dtype = getattr(torch, args.kv_cache_dtype)
    #     print("kv_cache_dtype:", args.kv_cache_dtype)
    #     config.kv_cache_dtype = args.kv_cache_dtype 

    if not hasattr(config, "text_max_length") and args.prompt is None:
        config.text_max_length = int(args.input_tokens) + int(args.max_new_tokens)
    
    model = AutoModelForCausalLM.from_pretrained(args.model_name_or_path, config=config, low_cpu_mem_usage=True)
    # with ipex._IPEXOnDevice(dtype=torch.float, device="cpu"):
    #     model = LlamaForCausalLM._from_config(config)
    # model = model.to(memory_format=torch.channels_last)

    tokenizer = AutoTokenizer.from_pretrained(args.model_name_or_path, trust_remote_code=True)
    
    if args.ipex:
        model = ipex._optimize_transformers(model.eval(), dtype=dtype, inplace=True)
    
    ### The quantization section 
    num_beams = 1 if args.greedy else 4
    beam_idx_tmp = torch.zeros((2048, int(args.batch_size * num_beams)), dtype=torch.long).contiguous()
    global_past_key_value = tuple(
        [
            (
                torch.zeros([1, model.config.num_attention_heads, 1, int(model.config.hidden_size/model.config.num_attention_heads),]).contiguous(),
                torch.zeros([1, model.config.num_attention_heads, 1, int(model.config.hidden_size/model.config.num_attention_heads),]).contiguous(),
                beam_idx_tmp,
                torch.zeros(1, dtype=torch.long).contiguous(),
            )
            for i in range(model.config.num_hidden_layers)
        ]
    )

    class Evaluator:
        def __init__(self, dataset, tokenizer, batch_size=8, pad_val=1, pad_max=196):
            self.dataset = dataset
            self.tokenizer = tokenizer
            self.batch_size = batch_size
            self.pad_val = pad_val
            self.pad_max = pad_max 

            # tokenize the dataset 
            self.dataset = self.dataset.map(self.tokenize_function, batched=True)
            self.dataset.set_format(type="torch", columns=["input_ids"])

        @torch.no_grad()
        def tokenize_function(self, examples):
            example = self.tokenizer(examples["prompt"])
            return example

        @torch.no_grad()
        def collate_batch(self, batch):
            position_ids_padded = []
            input_ids_padded = []
            last_ind = []
            attention_mask_padded = []
            for text in batch:
                input_ids = text["input_ids"] if text["input_ids"].shape[0] <= self.pad_max else text["input_ids"][0:int(self.pad_max-1)]
                pad_len = self.pad_max - input_ids.shape[0]
                last_ind.append(input_ids.shape[0] - 1)
                attention_mask = torch.ones(len(input_ids))
                position_ids = torch.arange(len(input_ids))
                input_ids  = pad(input_ids, (0, pad_len), value=self.pad_val)
                input_ids_padded.append(input_ids)
                attention_mask = pad(attention_mask, (0, pad_len), value=0)
                attention_mask_padded.append(attention_mask)
                position_ids = pad(position_ids, (0, pad_len), value=self.pad_val)
                position_ids_padded.append(position_ids)

            return(
                (
                    torch.vstack(input_ids_padded),
                    torch.vstack(attention_mask_padded),
                    torch.vstack(position_ids_padded),
                    tuple(global_past_key_value),
                ),
                torch.tensor(last_ind),
            )

    # Load the dataset
    #calib_dataset = load_dataset("openai_humaneval", split="test")
    calib_dataset = load_dataset("openai_humaneval", split="test")
    # evaluator = Evaluator(dataset, tokenizer, args.batch_size)
    calib_evaluator = Evaluator(calib_dataset, tokenizer, args.batch_size)
    calib_dataloader = DataLoader(calib_evaluator.dataset,
                                    batch_size=args.batch_size,
                                    shuffle=False,
                                    collate_fn=calib_evaluator.collate_batch,
                                )

    model.eval()

    prefix_size = int(args.input_tokens) - int(args.max_new_tokens)
    print("---- Prompt length: ", prefix_size)

    generate_kwargs = dict(do_sample=False, temperature=0.9, max_new_tokens=args.max_new_tokens, min_new_tokens=args.max_new_tokens, num_beams=1 if args.greedy else 4)
    
    if args.jit and not args.quantize:
        input_ids = torch.ones(32).to(torch.long)
        attention_mask = torch.ones(len(input_ids))
        position_ids = torch.arange(len(input_ids))
        example_inputs = {
            "input_ids": input_ids.unsqueeze(0),
            "attention_mask": attention_mask.unsqueeze(0),
            "position_ids": position_ids.unsqueeze(0),
            "past_key_values": global_past_key_value,
        }

        with torch.inference_mode(), torch.no_grad(), torch.autocast(
            device_type="cpu",
            enabled=amp_enabled,
            dtype=amp_dtype if amp_enabled else None,
        ):
            trace_model = torch.jit.trace(model, example_kwarg_inputs=example_inputs, strict=False, check_trace=False)
            trace_model = torch.jit.freeze(trace_model)
            setattr(model, "trace_graph", trace_model)

    quantized_model_path = args.output_dir + "/best_model.pt"
    if args.quantize:
        torch._C._jit_set_texpr_fuser_enabled(False)
        model = ipex._optimize_transformers(model.eval(), dtype=torch.int8, inplace=True)

        example_inputs = None
        for i, ((input_ids, attention_mask, position_ids, past_key_values), last_ind,) in enumerate(calib_dataloader):
            example_inputs = (input_ids, attention_mask, position_ids, past_key_values)
            break

        from intel_extension_for_pytorch.quantization import prepare, convert

        qconfig = ipex.quantization.get_smooth_quant_qconfig_mapping() #//smooth quant - static
        prepared_model = prepare(model.eval(), qconfig, example_inputs=example_inputs, inplace=True)
        with torch.no_grad():
            for i, ((input_ids, attention_mask, position_ids, past_key_values),last_ind,) in enumerate(calib_dataloader):
                if i == 8:
                    break
                
                prepared_model(
                    input_ids,
                    position_ids=position_ids,
                    attention_mask=attention_mask,
                    past_key_values=past_key_values,
                )

        with torch.no_grad(), torch.autocast(
            device_type="cpu",
            enabled=amp_enabled,
            dtype=amp_dtype if amp_enabled else None,
        ):
            converted_model = convert(prepared_model, inplace=True).eval()
            self_jit = torch.jit.trace(converted_model, example_inputs, strict=False)
            self_jit = torch.jit.freeze(self_jit.eval())
            self_jit.save(quantized_model_path)

    if args.token_latency:
        if not hasattr(model.config, "token_latency"):
            model.config.token_latency= True

    
    if args.dtype == "int8":
        if os.path.isfile(quantized_model_path):
            torch._C._jit_set_texpr_fuser_enabled(False)
            self_jit = torch.jit.load(quantized_model_path)
            with torch.no_grad():
                self_jit = torch.jit.freeze(self_jit.eval())
                setattr(model, "trace_graph", self_jit)
        else:
            raise FileNotFoundError("the quantized model was not found")

    if args.accuracy:
        # from intel_extension_for_transformers.llm.evaluation.lm_code_eval import evaluate
        results = measure_accuracy(
            model=model,
            tokenizer=tokenizer,
            dataloader=calib_dataloader,
            args=args,
        )
        print("Accuracy  >>=> %0.3f",results)

    if args.benchmark:
        print(model.config)
        benchmark_runtime(model=model,
                        tokenizer=tokenizer,
                        args=args,
                        generate_kwargs=generate_kwargs)

if __name__ == "__main__":
    main()
